"use client";

import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import {
  calculateEdge, calculateKelly, calculateSuggestedSizing,
  calculateUnrealizedROI, DEFAULT_KELLY
} from "@/lib/kelly";
import { storage } from "@/lib/storage";
import {
  extractSlugsFromUrl, resolveMarket, fetchClobPair, fetchClobPrice
} from "@/lib/polymarket";
import type {
  Report, User, Profile, Update, KellyCfg, RiskProfile,
  Side, Status, Outcome, Access
} from "@/lib/types";
import { ADMIN_EMAIL, ADMIN_PASS, capitalize, formatDate, timeAgo } from "@/lib/utils";
import ImageCropper from "@/components/ImageCropper";

/* =================== SEED =================== */
const SEED_REPORT: Report = {
  id: "rpt_seed_001",
  marketUrl: "https://polymarket.com/event/will-bitcoin-hit-150k-by-end-of-2026",
  eventSlug: "will-bitcoin-hit-150k-by-end-of-2026",
  marketSlug: null,
  tokenIdYes: null,
  tokenIdNo: null,
  livePriceYes: null,
  livePriceNo: null,
  title: "Will Bitcoin hit $150K by end of 2026?",
  category: "Crypto",
  side: "YES",
  entryPrice: 0.42,
  currentPrice: 0.42,
  fairValue: 0.58,
  resolutionDate: "2026-12-31",
  thesis:
    "Macro tailwinds combined with post-halving supply dynamics, sustained ETF inflows and structural institutional adoption support a meaningfully higher probability of BTC reaching $150K than the market is currently pricing.\n\nWe estimate fair probability at ~58% versus market price of 42%, implying material edge.",
  risks:
    "• Resolution source ambiguity if exchanges diverge.\n• Liquidity risk on Polymarket near resolution.\n• Position concentration — size accordingly with Kelly caps.\n• Macro shocks could compress crypto multiples.",
  imageDataUrl: "",
  access: "Free",
  status: "Published",
  outcome: "Open",
  createdAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
  lastPriceUpdate: 0
};
const SEED_UPDATE: Update = {
  id: "upd_seed_001",
  author: ADMIN_EMAIL,
  authorName: "Admin",
  avatar: "",
  text: "Welcome to Quantia Market Reports. New analyses go live here as we identify mispricings on Polymarket.",
  ts: Date.now() - 1000 * 60 * 60 * 24 * 2
};

type Route =
  | "dashboard" | "reports" | "risk" | "method" | "profile"
  | "updates"   | "upload"   | "manage" | "kelly";

/* =================== ROOT COMPONENT =================== */
export default function App() {
  // hydration-safe: render nothing on server, full app on client
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  // ---- state ----
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile>({ name: "", avatar: "" });
  const [reports, setReports] = useState<Report[]>([]);
  const [updates, setUpdates] = useState<Update[]>([]);
  const [risk, setRisk] = useState<RiskProfile>("balanced");
  const [bankroll, setBankroll] = useState<number>(0);
  const [kelly, setKelly] = useState<KellyCfg>(DEFAULT_KELLY);
  const [route, setRoute] = useState<Route>("dashboard");
  const [preview, setPreview] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [authMsg, setAuthMsg] = useState<{ kind: "err" | "ok"; text: string } | null>(null);
  const [openReportId, setOpenReportId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  /* ---- bootstrap ---- */
  useEffect(() => {
    if (!mounted) return;
    setTheme(storage.getTheme());
    let r = storage.getReports();
    if (!r.length) { r = [SEED_REPORT]; storage.setReports(r); }
    setReports(r);
    let u = storage.getUpdates();
    if (!u.length) { u = [SEED_UPDATE]; storage.setUpdates(u); }
    setUpdates(u);
    setRisk(storage.getRisk());
    setBankroll(storage.getBankroll());
    setKelly(storage.getKelly());
    const sess = storage.getSession();
    if (sess) {
      setUser(sess);
      setProfile(storage.getProfile(sess.email));
    }
  }, [mounted]);

  /* ---- theme apply ---- */
  useEffect(() => {
    if (!mounted) return;
    document.documentElement.setAttribute("data-theme", theme);
    storage.setTheme(theme);
  }, [theme, mounted]);

  /* ---- live price refresh every 60s ---- */
  const refreshAllPrices = useCallback(async () => {
    if (!user) return;
    const list = storage.getReports();
    if (!list.length) return;
    let changed = false;

    for (const r of list) {
      try {
        // Resolve token ids if missing
        if ((!r.tokenIdYes || !r.tokenIdNo) && r.marketUrl) {
          try {
            const resolved = await resolveMarket(r.marketUrl);
            r.tokenIdYes = resolved.yes.tokenId || r.tokenIdYes;
            r.tokenIdNo  = resolved.no.tokenId  || r.tokenIdNo;
            r.marketSlug = resolved.marketSlug || r.marketSlug;
            r.eventSlug  = resolved.eventSlug || r.eventSlug;
            // Gamma fallback prices
            if (resolved.yes.gammaPrice != null) r.livePriceYes = resolved.yes.gammaPrice;
            if (resolved.no.gammaPrice  != null) r.livePriceNo  = resolved.no.gammaPrice;
            changed = true;
          } catch { /* ignore */ }
        }
        // CLOB live prices
        const pair = await fetchClobPair(r.tokenIdYes, r.tokenIdNo);
        if (pair.yes != null) r.livePriceYes = pair.yes;
        if (pair.no  != null) r.livePriceNo  = pair.no;
        const newPrice = r.side === "YES" ? r.livePriceYes : r.livePriceNo;
        if (newPrice != null && Math.abs(newPrice - r.currentPrice) > 1e-6) {
          (r as any)._prevPrice = r.currentPrice;
          r.currentPrice = newPrice;
          r.lastPriceUpdate = Date.now();
          changed = true;
        } else if (newPrice != null && !r.lastPriceUpdate) {
          r.lastPriceUpdate = Date.now();
          changed = true;
        }
      } catch { /* ignore per-report */ }
    }

    if (changed) {
      storage.setReports(list);
      setReports([...list]);
      // clear flash flags after the animation has had time to fire
      setTimeout(() => {
        const cur = storage.getReports();
        cur.forEach((x: any) => { delete x._prevPrice; });
        storage.setReports(cur);
      }, 1000);
    }
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const t1 = setTimeout(refreshAllPrices, 1500); // first refresh shortly after login
    const t2 = setInterval(refreshAllPrices, 60_000); // then every 60s
    return () => { clearTimeout(t1); clearInterval(t2); };
  }, [user, refreshAllPrices]);

  /* ---- auth ---- */
  function doLogin(email: string, pass: string) {
    setAuthMsg(null);
    const e = email.trim().toLowerCase();
    if (!e || !pass) { setAuthMsg({ kind: "err", text: "Please enter email and password." }); return; }
    if (e === ADMIN_EMAIL && pass === ADMIN_PASS) {
      const u: User = { email: e, role: "admin", name: "Admin" };
      storage.setSession(u); setUser(u); setProfile(storage.getProfile(e));
      return;
    }
    const found = storage.getUsers().find(u => u.email === e && u.pass === pass);
    if (!found) { setAuthMsg({ kind: "err", text: "Invalid credentials." }); return; }
    const u: User = { email: e, role: "user", name: e.split("@")[0] };
    storage.setSession(u); setUser(u); setProfile(storage.getProfile(e));
  }
  function doRegister(email: string, pass: string) {
    setAuthMsg(null);
    const e = email.trim().toLowerCase();
    if (!e || !pass) { setAuthMsg({ kind: "err", text: "Please enter email and password." }); return; }
    if (pass.length < 6) { setAuthMsg({ kind: "err", text: "Password must be at least 6 characters." }); return; }
    if (e === ADMIN_EMAIL) { setAuthMsg({ kind: "err", text: "This email is reserved." }); return; }
    const users = storage.getUsers();
    if (users.find(u => u.email === e)) { setAuthMsg({ kind: "err", text: "An account with that email already exists." }); return; }
    users.push({ email: e, pass, createdAt: Date.now() });
    storage.setUsers(users);
    const u: User = { email: e, role: "user", name: e.split("@")[0] };
    storage.setSession(u); setUser(u); setProfile(storage.getProfile(e));
  }
  function doGoogle() {
    const e = "guest_" + Math.random().toString(36).slice(2, 7) + "@google.demo";
    const u: User = { email: e, role: "user", name: "Google User" };
    storage.setSession(u); setUser(u); setProfile(storage.getProfile(e));
  }
  function doLogout() {
    storage.clearSession(); setUser(null); setPreview(false);
  }

  /* ---- helpers ---- */
  const isAdmin = !!(user?.role === "admin" && !preview);
  function persistReports(next: Report[]) { storage.setReports(next); setReports(next); }
  function persistUpdates(next: Update[]) { storage.setUpdates(next); setUpdates(next); }

  /* =================== RENDER =================== */
  if (!mounted) return null;

  if (!user) {
    return (
      <AuthScreen
        mode={authMode}
        msg={authMsg}
        onSwitch={(m) => { setAuthMode(m); setAuthMsg(null); }}
        onLogin={doLogin}
        onRegister={doRegister}
        onGoogle={doGoogle}
        theme={theme}
        onToggleTheme={() => setTheme(theme === "dark" ? "light" : "dark")}
      />
    );
  }

  const opened = openReportId ? reports.find(r => r.id === openReportId) || null : null;

  return (
    <div className="relative z-[1] grid min-h-screen grid-cols-1 md:grid-cols-[240px_1fr]">
      <Sidebar
        isAdmin={isAdmin}
        route={route}
        onNavigate={(r) => { setRoute(r); setSidebarOpen(false); }}
        user={user}
        profile={profile}
        onLogout={doLogout}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      <div className="flex min-w-0 flex-col">
        <Topbar
          title={routeTitle(route)}
          isAdmin={isAdmin}
          showPreviewToggle={user.role === "admin"}
          previewOn={preview}
          onTogglePreview={() => setPreview(!preview)}
          theme={theme}
          onToggleTheme={() => setTheme(theme === "dark" ? "light" : "dark")}
          profile={profile}
          onProfile={() => setRoute("profile")}
          onMenu={() => setSidebarOpen(true)}
        />
        <main className="mx-auto w-full max-w-[1400px] flex-1 p-7 max-md:p-5">
          {route === "dashboard" && (
            <Dashboard
              reports={reports} updates={updates} risk={risk} kelly={kelly}
              bankroll={bankroll} profile={profile} isAdmin={isAdmin}
              onOpen={(id) => setOpenReportId(id)}
              onNavigate={(r) => setRoute(r)}
              onSetRisk={(r) => { setRisk(r); storage.setRisk(r); }}
            />
          )}
          {route === "reports" && (
            <ReportsList reports={reports} risk={risk} kelly={kelly} bankroll={bankroll}
                         onOpen={(id) => setOpenReportId(id)} />
          )}
          {route === "risk" && (
            <RiskPage risk={risk} kelly={kelly} bankroll={bankroll}
              onSetRisk={(r) => { setRisk(r); storage.setRisk(r); }}
              onSetBankroll={(b) => { setBankroll(b); storage.setBankroll(b); }} />
          )}
          {route === "method" && <MethodPage />}
          {route === "profile" && (
            <ProfilePage
              user={user} profile={profile}
              onSave={(p) => { setProfile(p); storage.setProfile(user.email, p); }}
            />
          )}
          {route === "updates" && (
            <UpdatesPage isAdmin={isAdmin} updates={updates} profile={profile} userEmail={user.email}
              onPost={(text) => {
                const u: Update = {
                  id: "upd_" + Date.now(),
                  author: user.email,
                  authorName: profile.name || user.name || "Admin",
                  avatar: profile.avatar || "",
                  text, ts: Date.now()
                };
                persistUpdates([u, ...updates]);
              }}
              onDelete={(id) => persistUpdates(updates.filter(u => u.id !== id))}
            />
          )}
          {route === "upload" && isAdmin && (
            <UploadPage
              editing={editingId ? reports.find(r => r.id === editingId) || null : null}
              onCancel={() => { setEditingId(null); setRoute("manage"); }}
              onSave={(r) => {
                const next = [...reports];
                const idx = next.findIndex(x => x.id === r.id);
                if (idx >= 0) next[idx] = r; else next.unshift(r);
                persistReports(next);
                setEditingId(null);
                setRoute("manage");
              }}
              onDelete={(id) => {
                if (!confirm("Delete this report?")) return;
                persistReports(reports.filter(x => x.id !== id));
                setEditingId(null);
                setRoute("manage");
              }}
            />
          )}
          {route === "manage" && isAdmin && (
            <ManagePage reports={reports}
              onOpen={(id) => setOpenReportId(id)}
              onEdit={(id) => { setEditingId(id); setRoute("upload"); }}
              onNew={() => { setEditingId(null); setRoute("upload"); }}
              onDelete={(id) => {
                if (!confirm("Delete this report?")) return;
                persistReports(reports.filter(x => x.id !== id));
              }}
            />
          )}
          {route === "kelly" && isAdmin && (
            <KellyPage kelly={kelly}
              onChange={(k) => { setKelly(k); storage.setKelly(k); }}
              onReset={() => { setKelly(DEFAULT_KELLY); storage.setKelly(DEFAULT_KELLY); }} />
          )}
        </main>
      </div>

      {opened && (
        <ReportModal
          report={opened}
          risk={risk} kelly={kelly} bankroll={bankroll}
          onClose={() => setOpenReportId(null)}
        />
      )}
    </div>
  );
}

/* =================== ROUTE TITLE =================== */
function routeTitle(r: Route): string {
  switch (r) {
    case "dashboard": return "Dashboard";
    case "reports":   return "All Reports";
    case "risk":      return "Risk Profile";
    case "method":    return "Methodology";
    case "profile":   return "My Profile";
    case "updates":   return "Admin Updates";
    case "upload":    return "Upload New Analysis";
    case "manage":    return "Manage Reports";
    case "kelly":     return "Kelly Settings";
  }
}

/* =================== AUTH SCREEN =================== */
function AuthScreen(props: {
  mode: "login" | "register";
  msg: { kind: "err" | "ok"; text: string } | null;
  onSwitch: (m: "login" | "register") => void;
  onLogin: (e: string, p: string) => void;
  onRegister: (e: string, p: string) => void;
  onGoogle: () => void;
  theme: "light" | "dark";
  onToggleTheme: () => void;
}) {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  return (
    <div className="relative z-[1] flex min-h-screen items-center justify-center p-6">
      <button className="theme-toggle absolute right-5 top-5" onClick={props.onToggleTheme} aria-label="Toggle theme">
        <ThemeIcon dark={props.theme === "dark"} />
      </button>
      <div className="auth-card w-full max-w-[440px]">
        <div className="mb-7 flex items-center gap-3">
          <div className="brand-mark">Q</div>
          <div>
            <div className="text-base font-bold tracking-tight">Quantia Market Reports</div>
            <div className="text-[11px] uppercase tracking-[0.12em]" style={{ color: "var(--text-2)" }}>
              Private Research Terminal
            </div>
          </div>
        </div>

        {props.mode === "login" ? (
          <>
            <h2 className="mb-1.5 text-2xl font-bold tracking-tight">Welcome back</h2>
            <p className="mb-7 text-[13px]" style={{ color: "var(--text-2)" }}>
              Sign in to access your research terminal.
            </p>
          </>
        ) : (
          <>
            <h2 className="mb-1.5 text-2xl font-bold tracking-tight">Create your account</h2>
            <p className="mb-7 text-[13px]" style={{ color: "var(--text-2)" }}>
              Get private access to Quantia research.
            </p>
          </>
        )}

        <Field label="Email">
          <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@domain.com" />
        </Field>
        <Field label="Password">
          <input className="input" type="password" value={pass} onChange={(e) => setPass(e.target.value)}
                 placeholder={props.mode === "register" ? "Min 6 characters" : "••••••••"}
                 onKeyDown={(e) => {
                   if (e.key === "Enter") {
                     props.mode === "login" ? props.onLogin(email, pass) : props.onRegister(email, pass);
                   }
                 }} />
        </Field>
        <button className="btn btn-primary btn-block btn-lg"
                onClick={() => props.mode === "login" ? props.onLogin(email, pass) : props.onRegister(email, pass)}>
          {props.mode === "login" ? "Sign in" : "Create account"}
        </button>

        {props.msg && <div className={"auth-msg " + (props.msg.kind === "ok" ? "success" : "")}>{props.msg.text}</div>}

        <div className="divider">or</div>
        <button className="google-btn" onClick={props.onGoogle}>
          <GoogleSvg /> Continue with Google
        </button>
        <div className="mt-4 text-center text-[13px]" style={{ color: "var(--text-2)" }}>
          {props.mode === "login" ? (
            <>Don&apos;t have an account?{" "}
              <a className="cursor-pointer font-semibold" style={{ borderBottom: "1px dashed var(--text-3)", color: "var(--text-0)" }}
                 onClick={() => props.onSwitch("register")}>Create one</a>
            </>
          ) : (
            <>Already have an account?{" "}
              <a className="cursor-pointer font-semibold" style={{ borderBottom: "1px dashed var(--text-3)", color: "var(--text-0)" }}
                 onClick={() => props.onSwitch("login")}>Sign in</a>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-3.5">
      <label className="mb-1.5 block text-[12px] font-medium" style={{ color: "var(--text-2)" }}>{label}</label>
      {children}
    </div>
  );
}

/* =================== SIDEBAR =================== */
function Sidebar(props: {
  isAdmin: boolean;
  route: Route;
  onNavigate: (r: Route) => void;
  user: User;
  profile: Profile;
  onLogout: () => void;
  open: boolean;
  onClose: () => void;
}) {
  const { isAdmin, route, onNavigate, user, profile } = props;
  const Item = ({ r, label, icon }: { r: Route; label: string; icon: React.ReactNode }) => (
    <div className={"nav-item " + (route === r ? "active" : "")} onClick={() => onNavigate(r)}>
      {icon}<span>{label}</span>
    </div>
  );
  return (
    <>
      <aside
        className={`sticky top-0 z-10 flex h-screen flex-col border-r p-5 backdrop-blur-xl
          max-md:fixed max-md:inset-y-0 max-md:left-0 max-md:w-[240px] max-md:transition-transform
          ${props.open ? "max-md:translate-x-0" : "max-md:-translate-x-full"}`}
        style={{ background: "var(--bg-sidebar)", borderColor: "var(--border)" }}
      >
        <div className="mb-7 flex items-center gap-3 px-1">
          <div className="brand-mark">Q</div>
          <div>
            <div className="text-base font-bold tracking-tight">Quantia</div>
            <div className="text-[11px] uppercase tracking-[0.12em]" style={{ color: "var(--text-2)" }}>Market Reports</div>
          </div>
        </div>
        <div className="px-3 pb-2 pt-3 text-[10px] font-semibold uppercase tracking-[0.14em]" style={{ color: "var(--text-3)" }}>Workspace</div>
        <Item r="dashboard" label="Dashboard" icon={<IconGrid />} />
        <Item r="reports"   label="All Reports" icon={<IconDoc />} />
        <Item r="updates"   label="Admin Updates" icon={<IconChat />} />
        <Item r="risk"      label="Risk Profile" icon={<IconClock />} />
        <Item r="profile"   label="My Profile" icon={<IconUser />} />
        <Item r="method"    label="Methodology" icon={<IconBook />} />

        {isAdmin && (
          <>
            <div className="px-3 pb-2 pt-3 text-[10px] font-semibold uppercase tracking-[0.14em]" style={{ color: "var(--text-3)" }}>Admin</div>
            <Item r="upload" label="Upload Analysis" icon={<IconUp />} />
            <Item r="manage" label="Manage Reports" icon={<IconList />} />
            <Item r="kelly"  label="Kelly Settings" icon={<IconCog />} />
          </>
        )}

        <div className="mt-auto border-t pt-3" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center gap-2.5 rounded-lg p-2">
            <Avatar size={32} name={profile.name || user.email} url={profile.avatar} />
            <div className="min-w-0 flex-1">
              <div className="truncate text-[12px] font-semibold" style={{ color: "var(--text-0)" }}>{profile.name || user.email}</div>
              <div className="text-[10px] uppercase tracking-[0.1em]" style={{ color: "var(--text-3)" }}>
                {isAdmin ? "Administrator" : "Analyst"}
              </div>
            </div>
          </div>
          <button className="btn btn-ghost btn-block mt-2 px-2 py-2 text-[12px]" onClick={props.onLogout}>
            <IconOut /> Sign out
          </button>
        </div>
      </aside>
      {props.open && (
        <div className="fixed inset-0 z-[9] bg-black/40 md:hidden" onClick={props.onClose} />
      )}
    </>
  );
}

/* =================== TOPBAR =================== */
function Topbar(props: {
  title: string;
  isAdmin: boolean;
  showPreviewToggle: boolean;
  previewOn: boolean;
  onTogglePreview: () => void;
  theme: "light" | "dark";
  onToggleTheme: () => void;
  profile: Profile;
  onProfile: () => void;
  onMenu: () => void;
}) {
  return (
    <header
      className="sticky top-0 z-[9] flex items-center justify-between gap-4 border-b px-7 py-4 backdrop-blur-xl max-md:px-5"
      style={{ background: "var(--bg-topbar)", borderColor: "var(--border)" }}
    >
      <div className="flex items-center gap-3">
        <button className="theme-toggle md:hidden" onClick={props.onMenu} aria-label="Open menu">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
        </button>
        <h1 className="text-lg font-bold tracking-tight">{props.title}</h1>
      </div>
      <div className="flex items-center gap-2.5">
        <span className="badge live">LIVE</span>
        <span className={"badge " + (props.isAdmin ? "admin" : "")}>{props.isAdmin ? "Admin" : "User"}</span>
        {props.showPreviewToggle && (
          <button className="btn btn-outline px-3 py-1.5 text-[11px]" onClick={props.onTogglePreview}>
            <IconEye />
            <span>{props.previewOn ? "Back to Admin" : "User Preview"}</span>
          </button>
        )}
        <button className="theme-toggle" onClick={props.onToggleTheme} aria-label="Toggle theme">
          <ThemeIcon dark={props.theme === "dark"} />
        </button>
        <button onClick={props.onProfile} aria-label="Profile">
          <Avatar size={32} name={props.profile.name || "U"} url={props.profile.avatar} />
        </button>
      </div>
    </header>
  );
}

/* =================== DASHBOARD =================== */
function Dashboard(props: {
  reports: Report[]; updates: Update[]; risk: RiskProfile; kelly: KellyCfg;
  bankroll: number; profile: Profile; isAdmin: boolean;
  onOpen: (id: string) => void;
  onNavigate: (r: Route) => void;
  onSetRisk: (r: RiskProfile) => void;
}) {
  const open = props.reports.filter(r => r.status === "Published" && r.outcome === "Open");
  const all  = props.reports.filter(r => r.status === "Published");
  const closed = all.filter(r => r.outcome !== "Open");
  const won = closed.filter(r => r.outcome === "Won").length;
  const hitRate = closed.length ? `${Math.round((won / closed.length) * 100)}%` : "—";
  const avgEdge = open.length ? `${(open.reduce((s, r) => s + calculateEdge(r.side, r.currentPrice, r.fairValue), 0) / open.length * 100).toFixed(1)}%` : "—";
  const last = [...all].sort((a, b) => b.createdAt - a.createdAt)[0];
  const lastTxt = last ? new Date(last.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "—";

  return (
    <>
      <PageHeader title={`Welcome back, ${props.profile.name || "analyst"}.`}
                  sub="Live overview of Quantia research and current open ideas."
                  right={props.isAdmin ? <button className="btn btn-primary" onClick={() => props.onNavigate("upload")}>+ New Analysis</button> : null} />

      <div className="mb-7 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Kpi label="Open Ideas" value={String(open.length)} delta="active research" up />
        <Kpi label="Average Edge" value={avgEdge} delta="vs market price" />
        <Kpi label="Hit Rate" value={hitRate} delta="closed positions" />
        <Kpi label="Last Report" value={lastTxt} delta="latest publication" small />
      </div>

      <Section title="Latest Reports" right={<button className="btn btn-ghost" onClick={() => props.onNavigate("reports")}>View all</button>}>
        <ReportsGrid list={all.slice(0, 6)} risk={props.risk} kelly={props.kelly} bankroll={props.bankroll} onOpen={props.onOpen} emptyMsg="No published reports yet." />
      </Section>

      <Section title="Open Ideas">
        <ReportsGrid list={open} risk={props.risk} kelly={props.kelly} bankroll={props.bankroll} onOpen={props.onOpen} emptyMsg="No open ideas at the moment." />
      </Section>

      <Section title="Closed Ideas">
        <ReportsGrid list={closed} risk={props.risk} kelly={props.kelly} bankroll={props.bankroll} onOpen={props.onOpen} emptyMsg="No closed ideas yet." />
      </Section>

      <Section title="Admin Updates" right={<button className="btn btn-ghost" onClick={() => props.onNavigate("updates")}>View all</button>}>
        <UpdatesFeed items={props.updates.slice(0, 3)} canDelete={false} />
      </Section>

      <Section title="Risk Profile" right={<button className="btn btn-ghost" onClick={() => props.onNavigate("risk")}>Configure</button>}>
        <div className="card p-5">
          <div className="risk-tabs">
            {(["conservative", "balanced", "aggressive"] as RiskProfile[]).map(p => (
              <button key={p} className={"risk-tab " + (props.risk === p ? "active" : "")} onClick={() => props.onSetRisk(p)}>{capitalize(p)}</button>
            ))}
          </div>
          <div className="text-[12.5px]" style={{ color: "var(--text-2)" }}>
            Kelly {props.kelly[props.risk].mult}× · Max {props.kelly[props.risk].cap}% per idea
            {props.bankroll > 0 ? ` · Bankroll $${props.bankroll.toLocaleString()}` : ""}
          </div>
        </div>
      </Section>
    </>
  );
}

function PageHeader({ title, sub, right }: { title: string; sub?: string; right?: React.ReactNode }) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4 max-md:flex-col max-md:items-start">
      <div>
        <h2 className="mb-1 text-2xl font-bold tracking-tight">{title}</h2>
        {sub && <p className="text-[13px]" style={{ color: "var(--text-2)" }}>{sub}</p>}
      </div>
      {right}
    </div>
  );
}
function Section({ title, right, children }: { title: string; right?: React.ReactNode; children: React.ReactNode }) {
  return (
    <section className="mb-8">
      <div className="mb-3.5 flex items-center justify-between gap-3">
        <h3 className="text-base font-bold tracking-tight">{title}</h3>
        {right}
      </div>
      {children}
    </section>
  );
}
function Kpi({ label, value, delta, up, small }: { label: string; value: string; delta?: string; up?: boolean; small?: boolean }) {
  return (
    <div className="card relative overflow-hidden p-5">
      <div className="mb-2.5 text-[11px] font-semibold uppercase tracking-[0.1em]" style={{ color: "var(--text-2)" }}>{label}</div>
      <div className={"font-mono font-bold tracking-tight " + (small ? "text-xl" : "text-[28px]")} style={{ color: "var(--text-0)" }}>{value}</div>
      {delta && (
        <div className={"mt-1.5 flex items-center gap-1 text-[12px] " + (up ? "text-[var(--green)]" : "")} style={{ color: up ? "var(--green)" : "var(--text-2)" }}>
          {up ? "▲ " : ""}{delta}
        </div>
      )}
    </div>
  );
}

/* =================== REPORTS GRID + CARD =================== */
function ReportsGrid(props: {
  list: Report[]; risk: RiskProfile; kelly: KellyCfg; bankroll: number;
  onOpen: (id: string) => void; emptyMsg: string;
}) {
  if (!props.list.length) {
    return (
      <div className="empty">
        <h4>Nothing here yet</h4>
        <div>{props.emptyMsg}</div>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {props.list.map(r => (
        <ReportCard key={r.id} report={r} risk={props.risk} kelly={props.kelly} bankroll={props.bankroll} onOpen={() => props.onOpen(r.id)} />
      ))}
    </div>
  );
}

function ReportCard({ report: r, risk, kelly, bankroll, onOpen }: {
  report: Report; risk: RiskProfile; kelly: KellyCfg; bankroll: number; onOpen: () => void;
}) {
  const edge = calculateEdge(r.side, r.currentPrice, r.fairValue);
  const k = calculateKelly(r.side, r.currentPrice, r.fairValue);
  const sizing = calculateSuggestedSizing(k, risk, kelly);
  const sizeUsd = bankroll > 0 ? ` · $${(sizing / 100 * bankroll).toFixed(0)}` : "";
  const roi = calculateUnrealizedROI(r.entryPrice, r.currentPrice, r.side);
  const prev = (r as any)._prevPrice as number | undefined;
  const flashClass = prev != null
    ? (r.currentPrice > prev ? "flash-up" : r.currentPrice < prev ? "flash-down" : "")
    : "";
  const isPremium = r.access === "Premium";
  const roiCls = roi > 0 ? "up" : roi < 0 ? "down" : "flat";
  const roiSign = roi > 0 ? "+" : "";

  return (
    <div className={"report-card " + (isPremium ? "premium" : "")} onClick={onOpen}>
      <div className="mb-2 flex items-start justify-between gap-2.5">
        <div className="text-[10px] font-semibold uppercase tracking-[0.12em]" style={{ color: "var(--text-3)" }}>{r.category || "General"}</div>
        <div className="flex flex-wrap gap-1.5">
          {isPremium && <span className="badge premium"><Crown /> PREMIUM</span>}
          <span className={"badge " + (r.side === "YES" ? "yes" : "no")}>{r.side}</span>
          <span className={"badge " + (r.outcome === "Open" ? "published" : r.outcome === "Won" ? "yes" : r.outcome === "Lost" ? "no" : "closed")}>{r.outcome}</span>
        </div>
      </div>
      <div className="mb-1.5 flex items-baseline gap-2 font-mono">
        <span className="text-[10px] font-semibold uppercase tracking-[0.12em]" style={{ color: "var(--text-3)" }}>Trading at</span>
        <span className={"text-lg font-bold tracking-tight " + flashClass} style={{ color: "var(--text-0)" }}>{(r.currentPrice * 100).toFixed(1)}%</span>
        <span className={"roi-pill " + roiCls}>{roiSign}{(roi * 100).toFixed(1)}% ROI</span>
      </div>
      <h4 className="mb-3.5 mt-2 line-clamp-2 text-[15px] font-semibold leading-snug tracking-tight" style={{ color: "var(--text-0)" }}>{r.title}</h4>
      <div className="metric-box mb-3.5 grid grid-cols-3 gap-2.5">
        <Metric label="Entry" value={`${(r.entryPrice * 100).toFixed(0)}¢`} />
        <Metric label="Fair Value" value={`${(r.fairValue * 100).toFixed(0)}¢`} />
        <Metric label="Edge" value={`${(edge * 100).toFixed(1)}%`} cls={edge >= 0 ? "text-[var(--green)]" : "text-[var(--red)]"} />
      </div>
      <div className="mt-auto flex items-center justify-between gap-2.5 border-t pt-3" style={{ borderColor: "var(--border)" }}>
        <div className="text-[11px]" style={{ color: "var(--text-2)" }}>
          Size: <strong className="font-mono">{sizing.toFixed(2)}%</strong>{sizeUsd} · Res. {formatDate(r.resolutionDate)}
        </div>
        <button className="btn btn-outline px-2.5 py-1.5 text-[11px]" onClick={(e) => { e.stopPropagation(); onOpen(); }}>View</button>
      </div>
    </div>
  );
}
function Metric({ label, value, cls }: { label: string; value: string; cls?: string }) {
  return (
    <div className="flex flex-col gap-0.5">
      <div className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--text-3)" }}>{label}</div>
      <div className={"font-mono text-sm font-semibold " + (cls || "")} style={{ color: cls ? undefined : "var(--text-0)" }}>{value}</div>
    </div>
  );
}

/* =================== REPORTS LIST PAGE =================== */
function ReportsList({ reports, risk, kelly, bankroll, onOpen }: {
  reports: Report[]; risk: RiskProfile; kelly: KellyCfg; bankroll: number; onOpen: (id: string) => void;
}) {
  const all = reports.filter(r => r.status === "Published");
  return (
    <>
      <PageHeader title="All Published Reports" sub={`${all.length} report${all.length === 1 ? "" : "s"} available in the terminal.`} />
      <ReportsGrid list={all} risk={risk} kelly={kelly} bankroll={bankroll} onOpen={onOpen} emptyMsg="No reports published yet." />
    </>
  );
}

/* =================== REPORT MODAL =================== */
function ReportModal({ report: r, risk, kelly, bankroll, onClose }: {
  report: Report; risk: RiskProfile; kelly: KellyCfg; bankroll: number; onClose: () => void;
}) {
  const edge = calculateEdge(r.side, r.currentPrice, r.fairValue);
  const k = calculateKelly(r.side, r.currentPrice, r.fairValue);
  const sizing = calculateSuggestedSizing(k, risk, kelly);
  const sizeUsd = bankroll > 0 ? ` (~$${(sizing / 100 * bankroll).toFixed(0)})` : "";
  const roi = calculateUnrealizedROI(r.entryPrice, r.currentPrice, r.side);
  const isPremium = r.access === "Premium";

  return (
    <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal">
        <div className="flex items-center justify-between gap-4 border-b px-6 py-5" style={{ borderColor: "var(--border)" }}>
          <h3 className="text-lg font-bold tracking-tight">Research Report</h3>
          <button className="theme-toggle" onClick={onClose} aria-label="Close">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-6">
          <div className="mb-5 h-[200px] w-full rounded-2xl border bg-cover bg-center"
               style={{ borderColor: "var(--border)", backgroundImage: r.imageDataUrl ? `url(${r.imageDataUrl})` : "linear-gradient(135deg,#e8e9f3,#dde0ef)" }}>
          </div>
          <div className="mb-2 flex items-center gap-2 text-[22px] font-bold tracking-tight" style={{ color: "var(--text-0)" }}>
            {isPremium && <Crown />} {r.title}
          </div>
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <span className="badge">{r.category || "General"}</span>
            <span className={"badge " + (r.side === "YES" ? "yes" : "no")}>Side: {r.side}</span>
            <span className={"badge " + (r.outcome === "Open" ? "published" : r.outcome === "Won" ? "yes" : r.outcome === "Lost" ? "no" : "closed")}>{r.outcome}</span>
            {isPremium && <span className="badge premium"><Crown /> PREMIUM</span>}
            {r.marketUrl && <a className="text-[12px]" style={{ color: "var(--accent-2)", borderBottom: "1px dashed currentColor" }}
                              href={r.marketUrl} target="_blank" rel="noopener noreferrer">Open on Polymarket ↗</a>}
          </div>

          <div className="mb-4 flex flex-wrap items-baseline gap-2.5">
            <div className="text-[12px] font-semibold uppercase tracking-[0.1em]" style={{ color: "var(--text-2)" }}>Trading at</div>
            <div className="font-mono text-[26px] font-bold" style={{ color: "var(--text-0)" }}>{(r.currentPrice * 100).toFixed(1)}%</div>
            <div className={"roi-pill " + (roi > 0 ? "up" : roi < 0 ? "down" : "flat")}>{roi > 0 ? "+" : ""}{(roi * 100).toFixed(1)}% Unrealized ROI</div>
          </div>

          <div className="mb-5 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
            <DetailMetric label="Entry" value={`${(r.entryPrice * 100).toFixed(0)}¢`} />
            <DetailMetric label="Quantia FV" value={`${(r.fairValue * 100).toFixed(0)}¢`} />
            <DetailMetric label="Edge" value={`${(edge * 100).toFixed(1)}%`} cls={edge >= 0 ? "text-[var(--green)]" : "text-[var(--red)]"} />
            <DetailMetric label="Kelly Sizing" value={`${sizing.toFixed(2)}%${sizeUsd}`} />
          </div>
          <div className="mb-4 text-[12px]" style={{ color: "var(--text-2)" }}>
            Resolution: <span className="font-mono" style={{ color: "var(--text-0)" }}>{formatDate(r.resolutionDate)}</span>
            {" · "} Last price update: <span className="font-mono">{r.lastPriceUpdate ? new Date(r.lastPriceUpdate).toLocaleTimeString() : "—"}</span>
          </div>

          <DetailSection title="Thesis"><p className="whitespace-pre-wrap text-[13.5px] leading-relaxed" style={{ color: "var(--text-1)" }}>{r.thesis || "—"}</p></DetailSection>
          <DetailSection title="Risks"><p className="whitespace-pre-wrap text-[13.5px] leading-relaxed" style={{ color: "var(--text-1)" }}>{r.risks || "—"}</p></DetailSection>

          <div className="mt-6 rounded-2xl border p-3.5 text-[11.5px] leading-relaxed"
               style={{ background: "rgba(217,119,6,0.06)", borderColor: "rgba(217,119,6,0.22)", color: "var(--amber)" }}>
            <strong>Disclaimer.</strong> Quantia Market Reports is independent research, not investment advice. Prediction markets carry substantial risk including total loss of capital. Sizing recommendations are based on the Kelly criterion adjusted for your selected risk profile and are illustrative only. You are solely responsible for your decisions.
          </div>
        </div>
        <div className="flex justify-end gap-2.5 border-t px-6 py-4" style={{ background: "var(--bg-2)", borderColor: "var(--border)" }}>
          {r.marketUrl && <a className="btn btn-outline" href={r.marketUrl} target="_blank" rel="noopener noreferrer">View on Polymarket</a>}
          <button className="btn btn-primary" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
function DetailMetric({ label, value, cls }: { label: string; value: string; cls?: string }) {
  return (
    <div className="metric-box">
      <div className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--text-3)" }}>{label}</div>
      <div className={"font-mono text-lg font-semibold " + (cls || "")} style={{ color: cls ? undefined : "var(--text-0)" }}>{value}</div>
    </div>
  );
}
function DetailSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-4">
      <h5 className="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.12em]" style={{ color: "var(--text-2)" }}>
        <span className="block h-3 w-[3px] rounded" style={{ background: "var(--accent-grad)" }} />
        {title}
      </h5>
      {children}
    </div>
  );
}

/* =================== UPLOAD PAGE =================== */
function UploadPage(props: {
  editing: Report | null;
  onCancel: () => void;
  onSave: (r: Report) => void;
  onDelete: (id: string) => void;
}) {
  const r = props.editing;
  const [marketUrl, setMarketUrl] = useState(r?.marketUrl || "");
  const [title,     setTitle]     = useState(r?.title || "");
  const [category,  setCategory]  = useState(r?.category || "");
  const [side,      setSide]      = useState<Side>(r?.side || "YES");
  const [fv,        setFv]        = useState<string>(r ? String(r.fairValue) : "");
  const [resolution,setResolution]= useState(r?.resolutionDate || "");
  const [thesis,    setThesis]    = useState(r?.thesis || "");
  const [risks,     setRisks]     = useState(r?.risks || "");
  const [access,    setAccess]    = useState<Access>(r?.access || "Free");
  const [status,    setStatus]    = useState<Status>(r?.status || "Draft");
  const [outcome,   setOutcome]   = useState<Outcome>(r?.outcome || "Open");
  const [imageDataUrl, setImageDataUrl] = useState(r?.imageDataUrl || "");

  // Detected from API (READ-ONLY for current price)
  const [eventSlug,  setEventSlug]  = useState<string | null>(r?.eventSlug || null);
  const [marketSlug, setMarketSlug] = useState<string | null>(r?.marketSlug || null);
  const [tokenIdYes, setTokenIdYes] = useState<string | null>(r?.tokenIdYes || null);
  const [tokenIdNo,  setTokenIdNo]  = useState<string | null>(r?.tokenIdNo  || null);
  const [livePriceYes, setLivePriceYes] = useState<number | null>(r?.livePriceYes ?? null);
  const [livePriceNo,  setLivePriceNo]  = useState<number | null>(r?.livePriceNo  ?? null);

  const [fetchLog, setFetchLog] = useState<{ kind: "info" | "ok" | "warn" | "err"; lines: string[] } | null>(null);
  const [fetching, setFetching] = useState(false);

  // Live "trading at" price for the selected side, derived from latest live data
  const sidePrice = side === "YES" ? livePriceYes : livePriceNo;

  async function handleFetch() {
    setFetchLog({ kind: "info", lines: ["Resolving market via Vercel API route…"] });
    setFetching(true);
    try {
      const slugs = extractSlugsFromUrl(marketUrl);
      if (!slugs.eventSlug && !slugs.marketSlug) {
        setFetchLog({ kind: "err", lines: ["Could not extract slug from URL.", "Expected: polymarket.com/event/<event>[/<market>]"] });
        setFetching(false); return;
      }
      const lines: string[] = [];
      lines.push(`• Event slug : ${slugs.eventSlug || "—"}`);
      lines.push(`• Market slug: ${slugs.marketSlug || "—"}`);
      lines.push(`• Calling /api/polymarket…`);
      setFetchLog({ kind: "info", lines: [...lines] });

      const resolved = await resolveMarket(marketUrl);
      (resolved.debug?.attempts || []).forEach(a => lines.push("   - " + a));
      lines.push(`✓ Source: ${resolved.source}`);
      lines.push(`• Question: ${resolved.market.question || "—"}`);
      lines.push(`• Outcomes: ${JSON.stringify(resolved.market.outcomes)}`);
      lines.push(`• Token YES: ${resolved.yes.tokenId ? resolved.yes.tokenId.slice(0, 18) + "…" : "—"}  gamma=${resolved.yes.gammaPrice ?? "—"}`);
      lines.push(`• Token NO : ${resolved.no.tokenId ? resolved.no.tokenId.slice(0, 18) + "…" : "—"}  gamma=${resolved.no.gammaPrice ?? "—"}`);
      lines.push(`• Querying live CLOB prices…`);
      setFetchLog({ kind: "info", lines: [...lines] });

      const pair = await fetchClobPair(resolved.yes.tokenId, resolved.no.tokenId);
      const liveY = pair.yes ?? resolved.yes.gammaPrice;
      const liveN = pair.no  ?? resolved.no.gammaPrice;
      lines.push(`• CLOB YES: ${pair.yes ?? "n/a (using Gamma)"}`);
      lines.push(`• CLOB NO : ${pair.no  ?? "n/a (using Gamma)"}`);
      lines.push(`• Selected side: ${side} → using ${liveY != null && side === "YES" ? Number(liveY).toFixed(4) : (liveN != null && side === "NO" ? Number(liveN).toFixed(4) : "—")}`);
      lines.push(`• Last updated: ${new Date().toLocaleTimeString()}`);
      lines.push("");
      lines.push("✓ Form populated with live data.");
      setFetchLog({ kind: "ok", lines });

      // Apply
      setEventSlug(resolved.eventSlug);
      setMarketSlug(resolved.marketSlug || resolved.market.slug);
      setTokenIdYes(resolved.yes.tokenId);
      setTokenIdNo(resolved.no.tokenId);
      setLivePriceYes(liveY);
      setLivePriceNo(liveN);
      if (resolved.market.question && !title) setTitle(resolved.market.question);
      if (resolved.market.category && !category) setCategory(resolved.market.category);
      if (resolved.market.endDate && !resolution) setResolution(String(resolved.market.endDate).slice(0, 10));
      if (resolved.market.image && !imageDataUrl) setImageDataUrl(resolved.market.image);
    } catch (err: any) {
      const lines: string[] = [];
      lines.push(`✗ Failed: ${err?.message || "unknown"}`);
      (err?.debug?.attempts || []).forEach((a: string) => lines.push("   - " + a));
      lines.push("Try another URL, or check Vercel server logs.");
      setFetchLog({ kind: "err", lines });
    } finally { setFetching(false); }
  }

  async function handleSave(forced?: Status) {
    if (!title.trim()) { alert("Title is required."); return; }
    if (!marketUrl.trim()) { alert("Market URL is required (auto-fetches price)."); return; }
    const fvNum = parseFloat(fv);
    if (!Number.isFinite(fvNum) || fvNum < 0 || fvNum > 1) { alert("Fair Value must be between 0 and 1."); return; }
    // Make sure we have a live price; refetch if not
    let priceYes = livePriceYes, priceNo = livePriceNo;
    let _tokenY = tokenIdYes, _tokenN = tokenIdNo;
    let _evSlug = eventSlug, _mkSlug = marketSlug;
    let _img = imageDataUrl;
    if (priceYes == null && priceNo == null) {
      try {
        const resolved = await resolveMarket(marketUrl);
        _evSlug = resolved.eventSlug;
        _mkSlug = resolved.marketSlug || resolved.market.slug;
        _tokenY = resolved.yes.tokenId; _tokenN = resolved.no.tokenId;
        const pair = await fetchClobPair(_tokenY, _tokenN);
        priceYes = pair.yes ?? resolved.yes.gammaPrice;
        priceNo  = pair.no  ?? resolved.no.gammaPrice;
        if (!_img && resolved.market.image) _img = resolved.market.image;
      } catch {
        alert("Could not fetch live price from Polymarket. Click Fetch Live first.");
        return;
      }
    }
    const livePrice = side === "YES" ? priceYes : priceNo;
    if (livePrice == null) {
      alert("Live price for the selected side is unavailable. Click Fetch Live and try again.");
      return;
    }

    const existing = r;
    const newReport: Report = {
      id: existing?.id || ("rpt_" + Date.now()),
      marketUrl,
      eventSlug: _evSlug,
      marketSlug: _mkSlug,
      tokenIdYes: _tokenY,
      tokenIdNo: _tokenN,
      livePriceYes: priceYes,
      livePriceNo: priceNo,
      title,
      category: category || "General",
      side,
      // entry locked at publish time (or first save). For edits, keep prior entry.
      entryPrice: existing?.entryPrice ?? livePrice,
      currentPrice: livePrice,
      fairValue: fvNum,
      resolutionDate: resolution,
      thesis,
      risks,
      imageDataUrl: _img || "",
      access,
      status: forced || status,
      outcome,
      createdAt: existing?.createdAt || Date.now(),
      lastPriceUpdate: Date.now()
    };
    props.onSave(newReport);
  }

  const tradingAt = sidePrice != null ? `${(sidePrice * 100).toFixed(1)}%` : "—";

  return (
    <>
      <PageHeader title={r ? "Edit Analysis" : "Upload New Analysis"}
                  sub={r ? "Update an existing report." : "Create a new research report. Live price is auto-detected from Polymarket."} />
      <div className="card max-w-[920px] p-6">
        {/* URL + fetch */}
        <div className="mb-4">
          <label className="mb-1.5 block text-[12px] font-medium" style={{ color: "var(--text-2)" }}>Polymarket URL</label>
          <div className="flex gap-2">
            <input className="input" type="url" value={marketUrl} onChange={(e) => setMarketUrl(e.target.value)}
                   placeholder="https://polymarket.com/event/<event>/<market>" />
            <button className="btn btn-outline" onClick={handleFetch} disabled={fetching}>{fetching ? "Fetching…" : "Fetch Live"}</button>
          </div>
          {fetchLog && (
            <div className={"fetch-status " + fetchLog.kind} style={{ marginTop: 8 }}>
              <div className="mb-1.5 font-semibold">Polymarket API trace</div>
              <pre>{fetchLog.lines.join("\n")}</pre>
            </div>
          )}
          {/* Live trading-at display (read-only) */}
          <div className="mt-3 flex flex-wrap items-baseline gap-3 rounded-xl border p-3" style={{ borderColor: "var(--border)", background: "var(--bg-metric)" }}>
            <span className="text-[10px] font-semibold uppercase tracking-[0.12em]" style={{ color: "var(--text-3)" }}>Trading at ({side})</span>
            <span className="font-mono text-2xl font-bold" style={{ color: "var(--text-0)" }}>{tradingAt}</span>
            {livePriceYes != null && <span className="badge yes">YES {(livePriceYes * 100).toFixed(1)}¢</span>}
            {livePriceNo  != null && <span className="badge no">NO {(livePriceNo  * 100).toFixed(1)}¢</span>}
            <span className="ml-auto text-[11px]" style={{ color: "var(--text-3)" }}>Auto-detected. Admin cannot edit price manually.</span>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
          <FieldFull label="Market title">
            <input className="input" type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Will X happen by Y?" />
          </FieldFull>

          <FieldFull label="Category">
            <input className="input" type="text" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Crypto, Politics, Sports..." />
          </FieldFull>

          <FieldFull label="Recommended side">
            <select className="select" value={side} onChange={(e) => setSide(e.target.value as Side)}>
              <option value="YES">YES</option>
              <option value="NO">NO</option>
            </select>
          </FieldFull>

          <FieldFull label={`Fair value for ${side} (0–1)`}>
            <input className="input" type="number" min={0} max={1} step={0.001} value={fv}
                   onChange={(e) => setFv(e.target.value)} placeholder="e.g. 0.58" />
          </FieldFull>

          <FieldFull label="Resolution date">
            <input className="input" type="date" value={resolution} onChange={(e) => setResolution(e.target.value)} />
          </FieldFull>

          <FieldFull label="Access type">
            <select className="select" value={access} onChange={(e) => setAccess(e.target.value as Access)}>
              <option value="Free">Free</option>
              <option value="Premium">Premium</option>
            </select>
          </FieldFull>

          <div className="sm:col-span-2">
            <label className="mb-1.5 block text-[12px] font-medium" style={{ color: "var(--text-2)" }}>Thesis</label>
            <textarea className="textarea" value={thesis} onChange={(e) => setThesis(e.target.value)} placeholder="Core argument…" />
          </div>
          <div className="sm:col-span-2">
            <label className="mb-1.5 block text-[12px] font-medium" style={{ color: "var(--text-2)" }}>Risks</label>
            <textarea className="textarea" value={risks} onChange={(e) => setRisks(e.target.value)} placeholder="Key risks to monitor…" />
          </div>

          <FieldFull label="Status">
            <select className="select" value={status} onChange={(e) => setStatus(e.target.value as Status)}>
              <option value="Draft">Draft</option>
              <option value="Published">Published</option>
              <option value="Closed">Closed</option>
            </select>
          </FieldFull>

          <FieldFull label="Outcome">
            <select className="select" value={outcome} onChange={(e) => setOutcome(e.target.value as Outcome)}>
              <option value="Open">Open</option>
              <option value="Won">Won</option>
              <option value="Lost">Lost</option>
              <option value="Invalid">Invalid</option>
            </select>
          </FieldFull>

          <div className="sm:col-span-2">
            <label className="mb-1.5 block text-[12px] font-medium" style={{ color: "var(--text-2)" }}>Image (drag, paste, or upload — then crop)</label>
            <ImageCropper value={imageDataUrl} onChange={setImageDataUrl} />
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2.5">
          <button className="btn btn-primary" onClick={() => handleSave("Published")}>Publish Analysis</button>
          <button className="btn btn-ghost" onClick={() => handleSave("Draft")}>Save Draft</button>
          {r && <button className="btn btn-danger" onClick={() => props.onDelete(r.id)}>Delete</button>}
          <button className="btn btn-outline" onClick={props.onCancel}>Cancel</button>
        </div>
      </div>
    </>
  );
}
function FieldFull({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1.5 block text-[12px] font-medium" style={{ color: "var(--text-2)" }}>{label}</label>
      {children}
    </div>
  );
}

/* =================== MANAGE PAGE =================== */
function ManagePage(props: {
  reports: Report[];
  onOpen: (id: string) => void;
  onEdit: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
}) {
  const list = [...props.reports].sort((a, b) => b.createdAt - a.createdAt);
  return (
    <>
      <PageHeader title="Manage Reports"
                  sub={`${list.length} report${list.length === 1 ? "" : "s"} · drafts and published.`}
                  right={<button className="btn btn-primary" onClick={props.onNew}>+ New Analysis</button>} />
      <div className="card overflow-hidden">
        {list.length === 0 ? (
          <div className="empty"><h4>No reports yet</h4><div>Click &quot;+ New Analysis&quot; to create your first one.</div></div>
        ) : (
          <div className="divide-y" style={{ borderColor: "var(--border)" }}>
            <div className="grid grid-cols-[2fr_1fr_1fr_1fr_1.2fr_1.5fr] items-center gap-3 px-5 py-3.5 text-[11px] font-semibold uppercase tracking-wider max-md:hidden"
                 style={{ background: "var(--bg-input)", color: "var(--text-2)" }}>
              <div>Title</div><div>Category</div><div>Side</div><div>Edge</div><div>Status</div><div className="text-right">Actions</div>
            </div>
            {list.map(r => {
              const edge = calculateEdge(r.side, r.currentPrice, r.fairValue);
              return (
                <div key={r.id} className="grid grid-cols-[2fr_1fr_1fr_1fr_1.2fr_1.5fr] items-center gap-3 px-5 py-3.5 text-[13px] max-md:grid-cols-1"
                     style={{ borderColor: "var(--border)", borderTop: "1px solid var(--border)" }}>
                  <div className="font-semibold" style={{ color: "var(--text-0)" }}>
                    {r.access === "Premium" && <Crown />} {r.title}
                  </div>
                  <div style={{ color: "var(--text-2)" }}>{r.category || "—"}</div>
                  <div><span className={"badge " + (r.side === "YES" ? "yes" : "no")}>{r.side}</span></div>
                  <div className="font-mono" style={{ color: edge >= 0 ? "var(--green)" : "var(--red)" }}>{(edge * 100).toFixed(1)}%</div>
                  <div><span className={"badge " + (r.status === "Published" ? "published" : r.status === "Draft" ? "draft" : "closed")}>{r.status}</span></div>
                  <div className="flex justify-end gap-1.5 max-md:justify-start">
                    <button className="btn btn-outline px-2.5 py-1.5 text-[11px]" onClick={() => props.onOpen(r.id)}>View</button>
                    <button className="btn btn-ghost px-2.5 py-1.5 text-[11px]" onClick={() => props.onEdit(r.id)}>Edit</button>
                    <button className="btn btn-danger px-2.5 py-1.5 text-[11px]" onClick={() => props.onDelete(r.id)}>Delete</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}

/* =================== KELLY PAGE =================== */
function KellyPage({ kelly, onChange, onReset }: {
  kelly: KellyCfg; onChange: (k: KellyCfg) => void; onReset: () => void;
}) {
  function update(p: keyof KellyCfg, field: "mult" | "cap", value: number) {
    onChange({ ...kelly, [p]: { ...kelly[p], [field]: value } });
  }
  return (
    <>
      <PageHeader title="Kelly Settings" sub="Configure risk multipliers and max position caps for each profile."
                  right={<button className="btn btn-ghost" onClick={onReset}>Reset defaults</button>} />
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-3">
        {(["conservative", "balanced", "aggressive"] as const).map(p => (
          <div key={p} className="card p-5">
            <h4 className="mb-3 flex items-center gap-2 text-sm font-bold" style={{ color: "var(--text-0)" }}>
              <span className={"h-2 w-2 rounded-full " + (p === "conservative" ? "bg-[#0ea5e9]" : p === "balanced" ? "bg-[var(--accent)]" : "bg-[var(--amber)]")} />
              {capitalize(p)}
            </h4>
            <div className="mb-3">
              <label className="mb-1.5 block text-[12px]" style={{ color: "var(--text-2)" }}>Kelly multiplier</label>
              <input className="input" type="number" min={0} max={1} step={0.01}
                     value={kelly[p].mult}
                     onChange={(e) => update(p, "mult", parseFloat(e.target.value) || 0)} />
            </div>
            <div>
              <label className="mb-1.5 block text-[12px]" style={{ color: "var(--text-2)" }}>Max position cap (% bankroll)</label>
              <input className="input" type="number" min={0} max={100} step={0.1}
                     value={kelly[p].cap}
                     onChange={(e) => update(p, "cap", parseFloat(e.target.value) || 0)} />
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

/* =================== RISK PAGE =================== */
function RiskPage({ risk, kelly, bankroll, onSetRisk, onSetBankroll }: {
  risk: RiskProfile; kelly: KellyCfg; bankroll: number;
  onSetRisk: (r: RiskProfile) => void; onSetBankroll: (b: number) => void;
}) {
  const [val, setVal] = useState<string>(bankroll ? String(bankroll) : "");
  return (
    <>
      <PageHeader title="Risk Profile" sub="Adjust your risk tolerance and bankroll. Sizing recommendations update live." />
      <div className="card max-w-[680px] p-6">
        <div className="mb-2.5 text-[12px] font-semibold uppercase tracking-[0.1em]" style={{ color: "var(--text-2)" }}>Profile</div>
        <div className="risk-tabs">
          {(["conservative", "balanced", "aggressive"] as RiskProfile[]).map(p => (
            <button key={p} className={"risk-tab " + (risk === p ? "active" : "")} onClick={() => onSetRisk(p)}>{capitalize(p)}</button>
          ))}
        </div>
        <div className="text-[12.5px] leading-relaxed" style={{ color: "var(--text-2)" }}>
          <strong style={{ color: "var(--text-0)" }}>{capitalize(risk)}</strong> applies a {kelly[risk].mult}× Kelly multiplier with a max position cap of {kelly[risk].cap}% of bankroll per idea.
        </div>
        <div className="mt-3.5 flex items-end gap-2.5">
          <div className="flex-1">
            <label className="mb-1.5 block text-[12px]" style={{ color: "var(--text-2)" }}>Bankroll (optional, USD)</label>
            <input className="input" type="number" min={0} step={100} value={val}
                   onChange={(e) => setVal(e.target.value)} placeholder="e.g. 10000" />
          </div>
          <button className="btn btn-primary" onClick={() => onSetBankroll(parseFloat(val) || 0)}>Save</button>
        </div>
        <div className="mt-2 text-[11.5px]" style={{ color: "var(--text-3)" }}>Used to display suggested $ position size on each report. Stored locally only.</div>
      </div>
    </>
  );
}

/* =================== METHODOLOGY PAGE =================== */
function MethodPage() {
  return (
    <>
      <PageHeader title="Methodology" sub="How Quantia derives fair value, edge and recommended sizing." />
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-3">
        {[
          { t: "Fair Value Modeling", d: "Each market is independently modeled using base rates, structural drivers and qualitative catalysts to estimate a Quantia probability." },
          { t: "Edge Detection",      d: "Edge is the spread between Quantia FV and current Polymarket price for the selected side. We only publish ideas with positive expected value." },
          { t: "Kelly Sizing",        d: "Position sizing follows fractional Kelly with risk-profile multipliers and hard caps to control drawdowns." }
        ].map(c => (
          <div key={c.t} className="card p-5">
            <div className="mb-3 grid h-9 w-9 place-items-center rounded-lg border" style={{ background: "linear-gradient(135deg,rgba(79,70,229,0.15),rgba(14,165,233,0.15))", borderColor: "rgba(79,70,229,0.22)" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
            </div>
            <h5 className="mb-1.5 text-sm font-bold" style={{ color: "var(--text-0)" }}>{c.t}</h5>
            <p className="text-[12.5px] leading-relaxed" style={{ color: "var(--text-2)" }}>{c.d}</p>
          </div>
        ))}
      </div>
      <div className="card mt-6 p-5">
        <h4 className="mb-2.5 text-sm font-bold">Side-aware formulas</h4>
        <div className="rounded-xl border p-3 font-mono text-[12.5px] leading-loose"
             style={{ background: "var(--bg-input)", borderColor: "var(--border)", color: "var(--accent-2)" }}>
          edge = fair_value − current_price <span style={{ color: "var(--text-3)" }}>// for the chosen side</span><br />
          kelly = (fair_value − current_price) / (1 − current_price)<br />
          sizing = clamp(kelly × risk_multiplier, 0, max_cap)<br />
          unrealized_ROI = (current_price − entry_price) / entry_price
        </div>
        <p className="mt-3 text-[13px] leading-relaxed" style={{ color: "var(--text-2)" }}>
          All inputs are expressed for the SELECTED side. For a NO bet at price 0.62 and FV 0.82, edge is +20pp.
          Negative Kelly values yield 0% sizing (no edge — pass).
        </p>
      </div>
    </>
  );
}

/* =================== UPDATES PAGE =================== */
function UpdatesPage(props: {
  isAdmin: boolean; updates: Update[]; profile: Profile; userEmail: string;
  onPost: (text: string) => void; onDelete: (id: string) => void;
}) {
  const [text, setText] = useState("");
  return (
    <>
      <PageHeader title="Admin Updates" sub="Quick notes, FV revisions and live commentary from Quantia." />
      {props.isAdmin && (
        <div className="card mb-4 max-w-[760px] p-4">
          <textarea className="textarea mb-2.5" placeholder="Share an update, FV revision, or quick note…"
                    value={text} onChange={(e) => setText(e.target.value)} />
          <div className="flex justify-end">
            <button className="btn btn-primary" disabled={!text.trim()} onClick={() => { props.onPost(text.trim()); setText(""); }}>
              Publish update
            </button>
          </div>
        </div>
      )}
      <div className="max-w-[760px]">
        <UpdatesFeed items={props.updates} canDelete={props.isAdmin} onDelete={props.onDelete} />
      </div>
    </>
  );
}
function UpdatesFeed({ items, canDelete, onDelete }: { items: Update[]; canDelete: boolean; onDelete?: (id: string) => void }) {
  if (!items.length) {
    return <div className="empty"><h4>No updates yet</h4><div>Updates published by Quantia admin will appear here.</div></div>;
  }
  return (
    <div className="flex flex-col gap-3">
      {[...items].sort((a, b) => b.ts - a.ts).map(u => (
        <div key={u.id} className="card flex items-start gap-3 p-3.5">
          <Avatar size={36} name={u.authorName} url={u.avatar} />
          <div className="min-w-0 flex-1">
            <div className="mb-1 flex items-center gap-2 text-[11px]" style={{ color: "var(--text-3)" }}>
              <strong className="text-[12px] font-semibold" style={{ color: "var(--text-0)" }}>{u.authorName || "Admin"}</strong>
              <span className="badge admin px-1.5 py-0.5 text-[9px]">ADMIN</span>
              <span>·</span>
              <span>{timeAgo(u.ts)}</span>
            </div>
            <div className="whitespace-pre-wrap break-words text-[13px] leading-relaxed" style={{ color: "var(--text-1)" }}>{u.text}</div>
          </div>
          {canDelete && onDelete && (
            <button className="btn btn-danger px-2.5 py-1 text-[11px]" onClick={() => onDelete(u.id)}>Delete</button>
          )}
        </div>
      ))}
    </div>
  );
}

/* =================== PROFILE PAGE =================== */
function ProfilePage({ user, profile, onSave }: { user: User; profile: Profile; onSave: (p: Profile) => void }) {
  const [name, setName] = useState(profile.name || "");
  const [avatar, setAvatar] = useState(profile.avatar || "");

  function onAvatarFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]; if (!f) return;
    const reader = new FileReader();
    reader.onload = (ev) => setAvatar(ev.target?.result as string);
    reader.readAsDataURL(f);
  }
  return (
    <>
      <PageHeader title="My Profile" sub="Personalize your terminal — name and avatar." />
      <div className="card max-w-[560px] p-6">
        <div className="mb-5 flex items-center gap-4">
          <Avatar size={64} name={name || user.email} url={avatar} />
          <div>
            <div className="text-base font-bold" style={{ color: "var(--text-0)" }}>{name || user.email}</div>
            <div className="text-[12px]" style={{ color: "var(--text-2)" }}>{user.email}</div>
          </div>
        </div>
        <FieldFull label="Display name">
          <input className="input" type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
        </FieldFull>
        <div className="mt-3.5">
          <label className="mb-1.5 block text-[12px]" style={{ color: "var(--text-2)" }}>Avatar (image file)</label>
          <input className="input" type="file" accept="image/*" onChange={onAvatarFile} />
          <div className="mt-1.5 text-[11px]" style={{ color: "var(--text-3)" }}>Stored locally only. Max ~1 MB recommended.</div>
        </div>
        <div className="mt-4 flex gap-2.5">
          <button className="btn btn-primary" onClick={() => onSave({ name, avatar })}>Save changes</button>
          {avatar && <button className="btn btn-ghost" onClick={() => { setAvatar(""); onSave({ name, avatar: "" }); }}>Remove avatar</button>}
        </div>
      </div>
    </>
  );
}

/* =================== SMALL UI =================== */
function Avatar({ size, name, url }: { size: number; name: string; url?: string }) {
  const initials = (name || "?").charAt(0).toUpperCase();
  return (
    <div className="avatar"
         style={{
           width: size, height: size,
           fontSize: size * 0.42,
           backgroundImage: url ? `url(${url})` : undefined
         }}>
      {!url && initials}
    </div>
  );
}
function ThemeIcon({ dark }: { dark: boolean }) {
  return dark ? (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>
  ) : (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
  );
}
function Crown() {
  return <svg className="crown" viewBox="0 0 24 24" fill="currentColor"><path d="M3 19h18l-1.5-9-4 3L12 6l-3.5 7-4-3L3 19z"/></svg>;
}
function GoogleSvg() {
  return (
    <svg width="16" height="16" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.7-6.1 8-11.3 8a12 12 0 1 1 0-24c3 0 5.8 1.1 7.9 3l5.7-5.7C34 5.1 29.3 3 24 3 12.4 3 3 12.4 3 24s9.4 21 21 21 21-9.4 21-21c0-1.2-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 16 19 13 24 13c3 0 5.8 1.1 7.9 3l5.7-5.7C34 5.1 29.3 3 24 3 16.3 3 9.7 7.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 45c5.2 0 10-2 13.6-5.2l-6.3-5.3c-2 1.5-4.6 2.5-7.3 2.5-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 40.6 16.2 45 24 45z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.2 4.2-4 5.6l6.3 5.3C41.4 35.9 45 30.5 45 24c0-1.2-.1-2.4-.4-3.5z"/></svg>
  );
}

/* nav icons */
function IconGrid()  { return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="9" rx="2"/><rect x="14" y="3" width="7" height="5" rx="2"/><rect x="14" y="12" width="7" height="9" rx="2"/><rect x="3" y="16" width="7" height="5" rx="2"/></svg>; }
function IconDoc()   { return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>; }
function IconChat()  { return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>; }
function IconClock() { return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>; }
function IconUser()  { return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>; }
function IconBook()  { return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>; }
function IconUp()    { return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>; }
function IconList()  { return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="8" y1="6"  x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6"  x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>; }
function IconCog()   { return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>; }
function IconEye()   { return <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>; }
function IconOut()   { return <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>; }
