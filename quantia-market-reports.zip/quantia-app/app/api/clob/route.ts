import { NextRequest, NextResponse } from "next/server";

export const runtime = "edge";
export const dynamic = "force-dynamic";

/**
 * /api/clob?token_id=...&side=BUY
 * Proxies https://clob.polymarket.com/price?token_id=...&side=BUY
 * Optional ?both=1 returns both YES and NO prices when given two ids:
 *   /api/clob?token_yes=...&token_no=...
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const tokenId = searchParams.get("token_id");
  const tokenYes = searchParams.get("token_yes");
  const tokenNo = searchParams.get("token_no");
  const side = (searchParams.get("side") || "BUY").toUpperCase();

  async function priceFor(t: string | null): Promise<number | null> {
    if (!t) return null;
    try {
      const r = await fetch(
        `https://clob.polymarket.com/price?token_id=${encodeURIComponent(t)}&side=${side}`,
        { headers: { accept: "application/json", "user-agent": "quantia-server" }, cache: "no-store" }
      );
      if (!r.ok) return null;
      const data = await r.json();
      const v = parseFloat((data && data.price) ?? data);
      return Number.isFinite(v) ? v : null;
    } catch {
      return null;
    }
  }

  if (tokenYes || tokenNo) {
    const [yes, no] = await Promise.all([priceFor(tokenYes), priceFor(tokenNo)]);
    return NextResponse.json({ yes, no });
  }

  if (!tokenId) {
    return NextResponse.json({ error: "Missing token_id" }, { status: 400 });
  }
  const price = await priceFor(tokenId);
  return NextResponse.json({ price });
}
