import { NextRequest, NextResponse } from "next/server";

export const runtime = "edge";
export const dynamic = "force-dynamic";

/**
 * /api/polymarket?url=<polymarket-event-or-market-url>
 *
 * Server-side: extracts slugs, then cascades through Gamma endpoints:
 *   1) https://gamma-api.polymarket.com/markets/slug/{marketSlug}
 *   2) https://gamma-api.polymarket.com/markets?slug={marketSlug}
 *   3) https://gamma-api.polymarket.com/events/slug/{eventSlug}
 *   4) https://gamma-api.polymarket.com/events?slug={eventSlug}
 *
 * Returns a normalized object with both YES/NO token ids + Gamma fallback prices.
 * Frontend never calls Polymarket directly → no CORS issues.
 */

type Slugs = { eventSlug: string | null; marketSlug: string | null };

function extractSlugsFromUrl(url: string): Slugs {
  if (!url) return { eventSlug: null, marketSlug: null };
  const clean = url.split("?")[0].split("#")[0];
  const eventMatch = clean.match(/polymarket\.com\/event\/([^/]+)(?:\/([^/]+))?/i);
  if (eventMatch) {
    return { eventSlug: eventMatch[1] || null, marketSlug: eventMatch[2] || null };
  }
  const marketMatch = clean.match(/polymarket\.com\/market\/([^/]+)/i);
  if (marketMatch) return { eventSlug: null, marketSlug: marketMatch[1] };
  return { eventSlug: null, marketSlug: null };
}

function parseList(v: unknown): any[] | null {
  if (Array.isArray(v)) return v;
  if (typeof v === "string") {
    try { return JSON.parse(v); } catch { return null; }
  }
  return null;
}

function normalizeMarket(m: any) {
  if (!m) return null;
  return {
    question: m.question || m.groupItemTitle || m.title || "",
    slug: m.slug || null,
    endDate: m.endDate || m.end_date_iso || null,
    image: m.image || m.icon || "",
    category: m.category || (Array.isArray(m.tags) && m.tags[0]?.label) || "",
    outcomes: parseList(m.outcomes) || [],
    outcomePrices: (parseList(m.outcomePrices) || []).map((x: any) => parseFloat(x)),
    clobTokenIds: parseList(m.clobTokenIds) || [],
    conditionId: m.conditionId || null
  };
}

async function gammaFetch(url: string): Promise<any> {
  const r = await fetch(url, {
    headers: { accept: "application/json", "user-agent": "quantia-server" },
    cache: "no-store"
  });
  if (!r.ok) throw new Error(`HTTP ${r.status} on ${url}`);
  return r.json();
}

function pickSideToken(norm: any, side: "YES" | "NO") {
  if (!norm) return { tokenId: null, gammaPrice: null, idx: -1 };
  let idx = (norm.outcomes || []).findIndex((o: any) => String(o).toUpperCase() === side);
  if (idx < 0) idx = side === "YES" ? 0 : 1;
  const tokenId = norm.clobTokenIds?.[idx] || null;
  const gammaPriceRaw = norm.outcomePrices?.[idx];
  const gammaPrice = Number.isFinite(gammaPriceRaw) ? gammaPriceRaw : null;
  return { tokenId, gammaPrice, idx };
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const url = searchParams.get("url");
  if (!url) {
    return NextResponse.json({ error: "Missing url query param" }, { status: 400 });
  }

  const { eventSlug, marketSlug } = extractSlugsFromUrl(url);
  const debug: { eventSlug: string | null; marketSlug: string | null; attempts: string[] } = {
    eventSlug, marketSlug, attempts: []
  };

  if (!eventSlug && !marketSlug) {
    return NextResponse.json(
      { error: "Could not extract slug from URL.", debug },
      { status: 400 }
    );
  }

  let normalized: any = null;
  let source = "";
  let eventTitle: string | undefined;

  // 1) markets/slug path
  if (marketSlug) {
    try {
      const data = await gammaFetch(
        `https://gamma-api.polymarket.com/markets/slug/${encodeURIComponent(marketSlug)}`
      );
      const m = Array.isArray(data) ? data[0] : data;
      if (m && (m.slug || m.question)) {
        normalized = normalizeMarket(m);
        source = "gamma:markets/slug";
        debug.attempts.push(`markets/slug/${marketSlug} → ok`);
      } else {
        debug.attempts.push(`markets/slug/${marketSlug} → empty`);
      }
    } catch (e: any) {
      debug.attempts.push(`markets/slug/${marketSlug} → ${e.message}`);
    }
  }

  // 2) markets?slug=
  if (!normalized && marketSlug) {
    try {
      const data = await gammaFetch(
        `https://gamma-api.polymarket.com/markets?slug=${encodeURIComponent(marketSlug)}`
      );
      const m = Array.isArray(data) ? data[0] : data;
      if (m && (m.slug || m.question)) {
        normalized = normalizeMarket(m);
        source = "gamma:markets?slug";
        debug.attempts.push(`markets?slug=${marketSlug} → ok`);
      } else {
        debug.attempts.push(`markets?slug=${marketSlug} → empty`);
      }
    } catch (e: any) {
      debug.attempts.push(`markets?slug=${marketSlug} → ${e.message}`);
    }
  }

  // 3) events/slug
  if (!normalized && eventSlug) {
    try {
      const data = await gammaFetch(
        `https://gamma-api.polymarket.com/events/slug/${encodeURIComponent(eventSlug)}`
      );
      const ev = Array.isArray(data) ? data[0] : data;
      const list = ev?.markets || [];
      let m = marketSlug ? list.find((x: any) => x.slug === marketSlug) : list[0];
      if (!m) m = list[0];
      if (m) {
        normalized = normalizeMarket(m);
        if (!normalized.image && ev.image) normalized.image = ev.image;
        if (!normalized.endDate && ev.endDate) normalized.endDate = ev.endDate;
        if (!normalized.category && ev.category) normalized.category = ev.category;
        source = "gamma:events/slug";
        eventTitle = ev.title;
        debug.attempts.push(`events/slug/${eventSlug} → ok`);
      } else {
        debug.attempts.push(`events/slug/${eventSlug} → empty`);
      }
    } catch (e: any) {
      debug.attempts.push(`events/slug/${eventSlug} → ${e.message}`);
    }
  }

  // 4) events?slug=
  if (!normalized && eventSlug) {
    try {
      const data = await gammaFetch(
        `https://gamma-api.polymarket.com/events?slug=${encodeURIComponent(eventSlug)}`
      );
      const ev = Array.isArray(data) ? data[0] : data;
      const list = ev?.markets || [];
      let m = marketSlug ? list.find((x: any) => x.slug === marketSlug) : list[0];
      if (!m) m = list[0];
      if (m) {
        normalized = normalizeMarket(m);
        if (!normalized.image && ev.image) normalized.image = ev.image;
        if (!normalized.endDate && ev.endDate) normalized.endDate = ev.endDate;
        if (!normalized.category && ev.category) normalized.category = ev.category;
        source = "gamma:events?slug";
        eventTitle = ev.title;
        debug.attempts.push(`events?slug=${eventSlug} → ok`);
      } else {
        debug.attempts.push(`events?slug=${eventSlug} → empty`);
      }
    } catch (e: any) {
      debug.attempts.push(`events?slug=${eventSlug} → ${e.message}`);
    }
  }

  if (!normalized) {
    return NextResponse.json(
      { error: "All Gamma endpoints failed.", debug },
      { status: 502 }
    );
  }

  const yesTok = pickSideToken(normalized, "YES");
  const noTok = pickSideToken(normalized, "NO");

  return NextResponse.json({
    source,
    eventSlug,
    marketSlug: marketSlug || normalized.slug,
    eventTitle,
    market: normalized,
    yes: { tokenId: yesTok.tokenId, gammaPrice: yesTok.gammaPrice },
    no: { tokenId: noTok.tokenId, gammaPrice: noTok.gammaPrice },
    debug
  });
}
