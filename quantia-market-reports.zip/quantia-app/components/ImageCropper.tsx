"use client";

import { useEffect, useRef, useState } from "react";

interface Props {
  value: string;
  onChange: (dataUrl: string) => void;
}

/**
 * Lightweight image picker + cropper.
 * - Drag & drop, paste from clipboard, file input
 * - Square crop preview (16:9 by default — good for report cards)
 * - Outputs base64 data URL
 */
export default function ImageCropper({ value, onChange }: Props) {
  const dropRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);

  const [src, setSrc] = useState<string>("");      // raw uploaded image
  const [zoom, setZoom] = useState<number>(1);
  const [offsetX, setOffsetX] = useState<number>(0);
  const [offsetY, setOffsetY] = useState<number>(0);
  const [dragging, setDragging] = useState(false);
  const dragStart = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);

  const TARGET_W = 800;
  const TARGET_H = 450; // 16:9

  function loadFile(file: File) {
    if (!file || !file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = () => {
      setSrc(reader.result as string);
      setZoom(1); setOffsetX(0); setOffsetY(0);
    };
    reader.readAsDataURL(file);
  }

  // Drag & drop
  useEffect(() => {
    const el = dropRef.current; if (!el) return;
    const prevent = (e: Event) => { e.preventDefault(); e.stopPropagation(); };
    const onDrop = (e: DragEvent) => {
      prevent(e);
      const f = e.dataTransfer?.files?.[0];
      if (f) loadFile(f);
    };
    el.addEventListener("dragover", prevent);
    el.addEventListener("dragenter", prevent);
    el.addEventListener("drop", onDrop);
    return () => {
      el.removeEventListener("dragover", prevent);
      el.removeEventListener("dragenter", prevent);
      el.removeEventListener("drop", onDrop);
    };
  }, []);

  // Paste from clipboard
  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items; if (!items) return;
      for (const it of Array.from(items)) {
        if (it.type.startsWith("image/")) {
          const f = it.getAsFile(); if (f) { loadFile(f); break; }
        }
      }
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, []);

  // Render preview to canvas whenever src/zoom/offset changes
  useEffect(() => {
    if (!src) return;
    const c = canvasRef.current; if (!c) return;
    const ctx = c.getContext("2d"); if (!ctx) return;
    const img = new Image();
    img.onload = () => {
      imgRef.current = img;
      drawTo(c, img, zoom, offsetX, offsetY);
    };
    img.src = src;
  }, [src]);

  useEffect(() => {
    const c = canvasRef.current; const img = imgRef.current;
    if (!c || !img) return;
    drawTo(c, img, zoom, offsetX, offsetY);
  }, [zoom, offsetX, offsetY]);

  function drawTo(c: HTMLCanvasElement, img: HTMLImageElement, z: number, ox: number, oy: number) {
    const ctx = c.getContext("2d")!;
    c.width = TARGET_W; c.height = TARGET_H;
    ctx.fillStyle = "#0b0e17";
    ctx.fillRect(0, 0, c.width, c.height);
    // Cover-fit base scale (so the image always covers the canvas at z=1)
    const base = Math.max(c.width / img.width, c.height / img.height);
    const drawW = img.width * base * z;
    const drawH = img.height * base * z;
    const dx = (c.width - drawW) / 2 + ox;
    const dy = (c.height - drawH) / 2 + oy;
    ctx.drawImage(img, dx, dy, drawW, drawH);
  }

  function startDrag(e: React.PointerEvent<HTMLCanvasElement>) {
    setDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY, ox: offsetX, oy: offsetY };
    (e.target as HTMLCanvasElement).setPointerCapture(e.pointerId);
  }
  function moveDrag(e: React.PointerEvent<HTMLCanvasElement>) {
    if (!dragging || !dragStart.current) return;
    const dx = e.clientX - dragStart.current.x;
    const dy = e.clientY - dragStart.current.y;
    setOffsetX(dragStart.current.ox + dx);
    setOffsetY(dragStart.current.oy + dy);
  }
  function endDrag() { setDragging(false); dragStart.current = null; }

  function applyCrop() {
    const c = canvasRef.current; if (!c) return;
    const data = c.toDataURL("image/jpeg", 0.85);
    onChange(data);
  }

  function clear() {
    setSrc("");
    onChange("");
  }

  return (
    <div className="space-y-3">
      <div
        ref={dropRef}
        className="border border-dashed rounded-xl p-4 text-center cursor-pointer transition hover:bg-[var(--bg-input)]"
        style={{ borderColor: "var(--border-strong)" }}
        onClick={() => document.getElementById("__cropper_file")?.click()}
      >
        <div className="text-sm font-medium" style={{ color: "var(--text-0)" }}>
          Drop image here, paste from clipboard, or click to upload
        </div>
        <div className="text-[11px] mt-1" style={{ color: "var(--text-3)" }}>
          PNG / JPG · max ~3 MB recommended · 16:9 crop
        </div>
        <input
          id="__cropper_file"
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) loadFile(f); }}
        />
      </div>

      {src && (
        <>
          <canvas
            ref={canvasRef}
            onPointerDown={startDrag}
            onPointerMove={moveDrag}
            onPointerUp={endDrag}
            onPointerCancel={endDrag}
            className="w-full rounded-xl border touch-none select-none cursor-grab active:cursor-grabbing"
            style={{ borderColor: "var(--border)", aspectRatio: "16/9" }}
          />
          <div className="flex items-center gap-3">
            <span className="text-[11px] uppercase tracking-wider font-semibold" style={{ color: "var(--text-3)" }}>Zoom</span>
            <input
              type="range" min={1} max={4} step={0.05}
              value={zoom}
              onChange={(e) => setZoom(parseFloat(e.target.value))}
              className="flex-1 accent-[var(--accent)]"
            />
            <button type="button" className="btn btn-primary" onClick={applyCrop}>Apply crop</button>
            <button type="button" className="btn btn-ghost" onClick={clear}>Clear</button>
          </div>
        </>
      )}

      {value && !src && (
        <div className="space-y-2">
          <div
            className="w-full rounded-xl border bg-cover bg-center"
            style={{ borderColor: "var(--border)", backgroundImage: `url(${value})`, aspectRatio: "16/9" }}
          />
          <button type="button" className="btn btn-ghost" onClick={clear}>Remove</button>
        </div>
      )}
    </div>
  );
}
