export type Side = "YES" | "NO";

export type RiskProfile = "conservative" | "balanced" | "aggressive";

export type Status = "Draft" | "Published" | "Closed";
export type Outcome = "Open" | "Won" | "Lost" | "Invalid";
export type Access = "Free" | "Premium";

export interface KellyCfg {
  conservative: { mult: number; cap: number };
  balanced:     { mult: number; cap: number };
  aggressive:   { mult: number; cap: number };
}

export interface Report {
  id: string;
  marketUrl: string;
  eventSlug: string | null;
  marketSlug: string | null;
  tokenIdYes: string | null;
  tokenIdNo: string | null;
  livePriceYes: number | null;
  livePriceNo: number | null;
  title: string;
  category: string;
  side: Side;
  /** Locked at publish time, expressed for the SELECTED side. */
  entryPrice: number;
  /** Latest live price for the SELECTED side. */
  currentPrice: number;
  /** Quantia FV expressed for the SELECTED side. */
  fairValue: number;
  resolutionDate: string;
  thesis: string;
  risks: string;
  imageDataUrl: string;
  access: Access;
  status: Status;
  outcome: Outcome;
  createdAt: number;
  lastPriceUpdate: number;
}

export interface User {
  email: string;
  role: "admin" | "user";
  name?: string;
}

export interface Profile {
  name: string;
  avatar: string; // base64 data URL
}

export interface Update {
  id: string;
  author: string;
  authorName: string;
  avatar: string;
  text: string;
  ts: number;
}
