"use client";

import type { Report, User, Profile, Update, KellyCfg, RiskProfile } from "./types";
import { DEFAULT_KELLY } from "./kelly";

const KEYS = {
  USERS:    "quantia_users",
  SESSION:  "quantia_session",
  REPORTS:  "quantia_reports",
  RISK:     "quantia_risk",
  BANKROLL: "quantia_bankroll",
  KELLY:    "quantia_kelly_settings",
  THEME:    "quantia_theme",
  UPDATES:  "quantia_updates",
  PROFILE:  "quantia_profile_"
} as const;

const safe = {
  get<T>(key: string, fallback: T): T {
    if (typeof window === "undefined") return fallback;
    try {
      const raw = localStorage.getItem(key);
      if (raw == null) return fallback;
      return JSON.parse(raw) as T;
    } catch { return fallback; }
  },
  set(key: string, val: unknown) {
    if (typeof window === "undefined") return;
    try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
  },
  raw(key: string): string | null {
    if (typeof window === "undefined") return null;
    try { return localStorage.getItem(key); } catch { return null; }
  },
  rawSet(key: string, val: string) {
    if (typeof window === "undefined") return;
    try { localStorage.setItem(key, val); } catch {}
  },
  remove(key: string) {
    if (typeof window === "undefined") return;
    try { localStorage.removeItem(key); } catch {}
  }
};

export const storage = {
  // Reports
  getReports: (): Report[] => safe.get<Report[]>(KEYS.REPORTS, []),
  setReports: (r: Report[]) => safe.set(KEYS.REPORTS, r),

  // Updates
  getUpdates: (): Update[] => safe.get<Update[]>(KEYS.UPDATES, []),
  setUpdates: (u: Update[]) => safe.set(KEYS.UPDATES, u),

  // Users
  getUsers: (): { email: string; pass: string; createdAt: number }[] =>
    safe.get(KEYS.USERS, []),
  setUsers: (u: any[]) => safe.set(KEYS.USERS, u),

  // Session
  getSession: (): User | null => safe.get<User | null>(KEYS.SESSION, null),
  setSession: (u: User) => safe.set(KEYS.SESSION, u),
  clearSession: () => safe.remove(KEYS.SESSION),

  // Risk + bankroll
  getRisk: (): RiskProfile => (safe.raw(KEYS.RISK) as RiskProfile) || "balanced",
  setRisk: (r: RiskProfile) => safe.rawSet(KEYS.RISK, r),
  getBankroll: (): number => parseFloat(safe.raw(KEYS.BANKROLL) || "0") || 0,
  setBankroll: (b: number) => safe.rawSet(KEYS.BANKROLL, String(b)),

  // Kelly cfg
  getKelly: (): KellyCfg => ({ ...DEFAULT_KELLY, ...safe.get<Partial<KellyCfg>>(KEYS.KELLY, {}) }),
  setKelly: (k: KellyCfg) => safe.set(KEYS.KELLY, k),

  // Theme
  getTheme: (): "light" | "dark" => (safe.raw(KEYS.THEME) === "dark" ? "dark" : "light"),
  setTheme: (t: "light" | "dark") => safe.rawSet(KEYS.THEME, t),

  // Profile (per email)
  getProfile: (email: string): Profile =>
    safe.get<Profile>(KEYS.PROFILE + email, { name: email.split("@")[0], avatar: "" }),
  setProfile: (email: string, p: Profile) => safe.set(KEYS.PROFILE + email, p)
};
