/**
 * Frontend client. Always hits OUR API routes — never Polymarket directly.
 * This keeps the browser free of CORS issues on Vercel.
 */

export type Slugs = { eventSlug: string | null; marketSlug: string | null };

export function extractSlugsFromUrl(url: string): Slugs {
  if (!url) return { eventSlug: null, marketSlug: null };
  const clean = url.split("?")[0].split("#")[0];
  const eventMatch = clean.match(/polymarket\.com\/event\/([^/]+)(?:\/([^/]+))?/i);
  if (eventMatch) {
    return { eventSlug: eventMatch[1] || null, marketSlug: eventMatch[2] || null };
  }
  const marketMatch = clean.match(/polymarket\.com\/market\/([^/]+)/i);
  if (marketMatch) return { eventSlug: null, marketSlug: marketMatch[1] };
  return { eventSlug: null, marketSlug: null };
}

export interface PolymarketResolved {
  source: string;
  eventSlug: string | null;
  marketSlug: string | null;
  eventTitle?: string;
  market: {
    question: string;
    slug: string | null;
    endDate: string | null;
    image: string;
    category: string;
    outcomes: string[];
    outcomePrices: number[];
    clobTokenIds: string[];
    conditionId: string | null;
  };
  yes: { tokenId: string | null; gammaPrice: number | null };
  no:  { tokenId: string | null; gammaPrice: number | null };
  debug: { eventSlug: string | null; marketSlug: string | null; attempts: string[] };
}

export async function resolveMarket(url: string): Promise<PolymarketResolved> {
  const r = await fetch(`/api/polymarket?url=${encodeURIComponent(url)}`, {
    cache: "no-store"
  });
  if (!r.ok) {
    const data = await r.json().catch(() => ({}));
    const err = new Error(data?.error || `HTTP ${r.status}`) as any;
    err.debug = data?.debug;
    throw err;
  }
  return r.json();
}

export async function fetchClobPrice(tokenId: string | null): Promise<number | null> {
  if (!tokenId) return null;
  try {
    const r = await fetch(`/api/clob?token_id=${encodeURIComponent(tokenId)}&side=BUY`, {
      cache: "no-store"
    });
    if (!r.ok) return null;
    const data = await r.json();
    const v = parseFloat(data?.price);
    return Number.isFinite(v) ? v : null;
  } catch {
    return null;
  }
}

export async function fetchClobPair(
  tokenYes: string | null,
  tokenNo: string | null
): Promise<{ yes: number | null; no: number | null }> {
  if (!tokenYes && !tokenNo) return { yes: null, no: null };
  const qs = new URLSearchParams();
  if (tokenYes) qs.set("token_yes", tokenYes);
  if (tokenNo) qs.set("token_no", tokenNo);
  qs.set("side", "BUY");
  try {
    const r = await fetch(`/api/clob?${qs.toString()}`, { cache: "no-store" });
    if (!r.ok) return { yes: null, no: null };
    return r.json();
  } catch {
    return { yes: null, no: null };
  }
}
