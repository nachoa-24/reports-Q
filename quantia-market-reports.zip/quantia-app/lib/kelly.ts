import type { Side, KellyCfg, RiskProfile } from "./types";

export const DEFAULT_KELLY: KellyCfg = {
  conservative: { mult: 0.10, cap: 2.5 },
  balanced:     { mult: 0.25, cap: 5.0 },
  aggressive:   { mult: 0.50, cap: 10.0 }
};

/**
 * Convention: price and fv are ALREADY expressed for the selected side.
 * If side=NO and you bought NO at 0.62 with FV 0.82, edge = +20pp.
 * Side parameter is kept in the signature for clarity but does not
 * change the math — it's a reminder that inputs are side-scoped.
 */
export function calculateEdge(_side: Side, price: number, fv: number): number {
  if (!Number.isFinite(price) || !Number.isFinite(fv)) return 0;
  return fv - price;
}

export function calculateKelly(_side: Side, price: number, fv: number): number {
  if (!Number.isFinite(price) || !Number.isFinite(fv)) return 0;
  if (price <= 0 || price >= 1) return 0;
  const k = (fv - price) / (1 - price);
  return Math.max(0, k); // negative -> pass
}

export function calculateSuggestedSizing(
  kelly: number,
  riskProfile: RiskProfile,
  cfg: KellyCfg = DEFAULT_KELLY
): number {
  const c = cfg[riskProfile];
  if (!c) return 0;
  let size = kelly * c.mult * 100; // %
  size = Math.min(size, c.cap);
  return Math.max(0, size);
}

/**
 * ROI on the selected-side position.
 * If you bought side at entryPrice and it now trades at currentPrice,
 * your share moved (currentPrice - entryPrice) / entryPrice.
 */
export function calculateUnrealizedROI(
  entryPrice: number,
  currentPrice: number,
  _side: Side
): number {
  if (!Number.isFinite(entryPrice) || !Number.isFinite(currentPrice)) return 0;
  if (entryPrice <= 0) return 0;
  return (currentPrice - entryPrice) / entryPrice;
}
